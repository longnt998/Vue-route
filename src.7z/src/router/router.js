import HomePage from '../pages/home/IndexHome.vue';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: HomePage
  },
];

export default routes
