<template>
  <div>
    <HomePage :message="message" @changeMessage="changeMessage" />
  </div>
</template>
<script>
import HomePage from "../../components/home/HomePage.vue";

export default {
  name: 'HomePage',
  components: {
    HomePage,
  },
  data() {
    return {
      message: "Welcome to Your Vuejs",
    };
  },
  methods: {
    changeMessage(value) {
      this.message = value;
    },
  },
};
</script>
