<template>
  <div class="box-card">
    <div class="box-card-home text-center">
      <img alt="Vue logo" src="../../assets/logo.png">
      <h3>{{ message }}</h3>
      <button class="btn btn-link" @click="changeMessage">
        Change message
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  props: ['message'],
  methods: {
    changeMessage() {
      this.$emit("changeMessage", "You change the text");
    },
  },
};
</script>
